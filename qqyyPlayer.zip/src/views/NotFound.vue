<template>
  <div>
    <h1 style="color:red" class="notFound">404:Not Found</h1>
  </div>
</template>
<script>
export default {
  
}
</script>
<style scoped>
  .notFound{
    font-size:32px;
  }
</style>