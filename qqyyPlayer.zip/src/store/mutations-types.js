export const setPlaylist = "setPlaylist" // 修改正在播放列表
export const setPlaying = "setPlaying" // 修改播放状态
export const setCurrentIndex = "setCurrentIndex" // 修改播放下标
export const setDeleteMessage = "setDeleteMessage" // 修改删除的的提示信息
export const setAudioEle = "setAudioEle" // 修改audio元素