<template>
  <div id="">
      
  </div>
</template>

<script>
// import {} from "";

export default {
  name:'',
  components:{},
  flters:{},
  props:{},
  data(){
    return{}
  },
  computed:{},
  watch:{},
  // activated:{},
  methods:{},
  created(){},
  mounted(){},
  // render(){}, // html模板
}
</script>

<style lang="less">
  
</style>